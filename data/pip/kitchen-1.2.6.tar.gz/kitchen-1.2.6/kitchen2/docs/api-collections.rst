===================
Kitchen.collections
===================

.. automodule:: kitchen.collections.strictdict
    :members:
