===============================
Helpers for versioning software
===============================

.. automodule:: kitchen.versioning
    :members:
