==========
Exceptions
==========

Kitchen has a hierarchy of exceptions that should make it easy to catch many
errors emitted by kitchen itself.

.. automodule:: kitchen.exceptions
    :members:

.. automodule:: kitchen.text.exceptions
    :members:
