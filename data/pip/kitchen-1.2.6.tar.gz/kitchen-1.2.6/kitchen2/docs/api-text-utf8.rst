.. automodule:: kitchen.text.utf8
    :members:
    :deprecated:
